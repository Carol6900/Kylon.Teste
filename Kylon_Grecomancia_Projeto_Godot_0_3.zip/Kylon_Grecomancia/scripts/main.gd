extends Node

const WorldScript = preload("res://scripts/world.gd")

var selected_name := "Ariadne"
var selected_body := "Feminino"
var selected_race := "Humano"
var selected_class := "Guerreiro"
var selected_subclass := "Guardião"
var selected_hair := "Longo"
var selected_mode := "Campanha"

var ui_root: Control

func _ready() -> void:
    show_title()

func clear_ui() -> void:
    for child in get_children():
        remove_child(child)
        child.queue_free()
    ui_root = Control.new()
    ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(ui_root)

func make_label(parent: Control, text_value: String, size: int = 22) -> Label:
    var label := Label.new()
    label.text = text_value
    label.add_theme_font_size_override("font_size", size)
    label.add_theme_color_override("font_color", Color(0.96, 0.91, 0.79))
    parent.add_child(label)
    return label

func make_button(parent: Control, text_value: String, callback: Callable) -> Button:
    var button := Button.new()
    button.text = text_value
    button.custom_minimum_size = Vector2(260, 54)
    button.add_theme_font_size_override("font_size", 20)
    button.pressed.connect(callback)
    parent.add_child(button)
    return button

func centered_panel() -> VBoxContainer:
    clear_ui()
    var background := ColorRect.new()
    background.color = Color(0.055, 0.075, 0.12, 1)
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui_root.add_child(background)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui_root.add_child(center)
    var panel := VBoxContainer.new()
    panel.custom_minimum_size = Vector2(440, 0)
    panel.add_theme_constant_override("separation", 16)
    center.add_child(panel)
    return panel

func show_title() -> void:
    var panel := centered_panel()
    make_label(panel, "KYLON", 54)
    make_label(panel, "GRECOMANCIA", 24)
    make_label(panel, "Um RPG de fantasia inspirado na mitologia grega.", 16)
    make_button(panel, "NOVA CAMPANHA", func(): selected_mode = "Campanha"; show_character_creator())
    make_button(panel, "JOGO LIVRE", func(): selected_mode = "Jogo Livre"; show_character_creator())
    make_button(panel, "CONTINUAR", func(): show_message("Ainda não há uma partida salva."))
    make_button(panel, "CONFIGURAÇÕES", func(): show_message("Configurações serão adicionadas em uma próxima versão."))
    make_label(panel, "Protótipo inicial • versão 0.1", 13)

func show_message(message: String) -> void:
    var panel := centered_panel()
    make_label(panel, message, 22)
    make_button(panel, "VOLTAR", show_title)

func add_option(parent: VBoxContainer, title: String, options: Array, current: String, setter: Callable) -> void:
    make_label(parent, title, 17)
    var picker := OptionButton.new()
    picker.custom_minimum_size = Vector2(340, 42)
    for option in options:
        picker.add_item(str(option))
    var idx := options.find(current)
    picker.select(maxi(0, idx))
    picker.item_selected.connect(func(index: int): setter.call(str(options[index])))
    parent.add_child(picker)

func show_character_creator() -> void:
    var panel := centered_panel()
    make_label(panel, "CRIAÇÃO DE PERSONAGEM", 30)
    make_label(panel, "Escolha sua aparência e seu caminho.", 16)

    var name_input := LineEdit.new()
    name_input.placeholder_text = "Nome do personagem"
    name_input.text = selected_name
    name_input.custom_minimum_size = Vector2(340, 42)
    panel.add_child(name_input)

    add_option(panel, "Corpo / anatomia", ["Feminino", "Masculino", "Intersexo", "Fantástico"], selected_body, func(v): selected_body = v)
    add_option(panel, "Raça", ["Humano", "Elfo", "Centauro", "Sátiro", "Sereiano", "Semideus", "Ciclope", "Dríade", "Harpia", "Górgona"], selected_race, func(v): selected_race = v)
    add_option(panel, "Classe principal", ["Guerreiro", "Mago", "Arqueiro", "Assassino", "Clérigo", "Invocador"], selected_class, func(v): selected_class = v)
    add_option(panel, "Especialização", ["Guardião", "Berserker", "Elementalista", "Oráculo", "Caçador", "Sombras", "Curandeiro", "Espiritualista"], selected_subclass, func(v): selected_subclass = v)
    add_option(panel, "Cabelo", ["Curto", "Médio", "Longo", "Cacheado", "Trançado", "Careca"], selected_hair, func(v): selected_hair = v)

    var start := Button.new()
    start.text = "ENTRAR NO MUNDO"
    start.custom_minimum_size = Vector2(340, 54)
    start.add_theme_font_size_override("font_size", 20)
    start.pressed.connect(func():
        selected_name = name_input.text.strip_edges()
        if selected_name.is_empty():
            selected_name = "Aventureiro"
        start_game()
    )
    panel.add_child(start)
    make_button(panel, "VOLTAR", show_title)

func start_game() -> void:
    clear_ui()
    var world := Node3D.new()
    world.set_script(WorldScript)
    world.player_data = {
        "mode": selected_mode,
        "name": selected_name,
        "body": selected_body,
        "race": selected_race,
        "class": selected_class,
        "subclass": selected_subclass,
        "hair": selected_hair
    }
    add_child(world)
