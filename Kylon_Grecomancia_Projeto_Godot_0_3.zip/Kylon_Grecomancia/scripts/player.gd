extends CharacterBody3D

var speed := 6.0

func _physics_process(delta: float) -> void:
    var input_vector := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    if input_vector.length() > 1.0:
        input_vector = input_vector.normalized()

    # Movimento relativo à câmera isométrica
    var direction := Vector3(input_vector.x, 0, input_vector.y)
    direction = direction.rotated(Vector3.UP, deg_to_rad(-45.0))
    velocity.x = direction.x * speed
    velocity.z = direction.z * speed
    if not is_on_floor():
        velocity.y -= 24.0 * delta
    else:
        velocity.y = 0.0
    move_and_slide()
