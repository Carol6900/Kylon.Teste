extends Node3D

var player_data: Dictionary = {}
var player: CharacterBody3D
var enemy: CharacterBody3D
var health := 100
var enemy_health := 50
var status_label: Label
var quest_label: Label
var attack_cooldown := 0.0

func _ready() -> void:
    build_world()
    build_player()
    build_enemy()
    build_hud()

func material(color: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.85
    return mat

func add_box(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = size
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.position = pos
    instance.material_override = material(color)
    parent.add_child(instance)
    return instance

func build_world() -> void:
    var ground := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(70, 70)
    ground.mesh = plane
    ground.material_override = material(Color(0.23, 0.36, 0.25))
    ground.rotation.x = 0
    add_child(ground)

    # Piso físico para impedir que o personagem atravesse o cenário.
    var floor_body := StaticBody3D.new()
    floor_body.position = Vector3(0, -0.5, 0)
    var floor_collision := CollisionShape3D.new()
    var floor_shape := BoxShape3D.new()
    floor_shape.size = Vector3(70, 1, 70)
    floor_collision.shape = floor_shape
    floor_body.add_child(floor_collision)
    add_child(floor_body)

    # Caminho de pedra e colunas decorativas
    for i in range(8):
        add_box(self, Vector3(3.2, 0.12, 2.0), Vector3(0, 0.08, -float(i) * 2.5), Color(0.62, 0.58, 0.48))
    for x in [-8.0, 8.0]:
        for z in [-8.0, -2.0, 4.0]:
            var pillar := MeshInstance3D.new()
            var cylinder := CylinderMesh.new()
            cylinder.top_radius = 0.55
            cylinder.bottom_radius = 0.7
            cylinder.height = 4.0
            pillar.mesh = cylinder
            pillar.position = Vector3(x, 2.0, z)
            pillar.material_override = material(Color(0.82, 0.78, 0.67))
            add_child(pillar)
            add_box(self, Vector3(1.8, 0.3, 1.8), Vector3(x, 4.1, z), Color(0.9, 0.82, 0.64))

    # Árvores simples para dar escala ao cenário
    for p in [Vector3(-13,0,-9), Vector3(13,0,-13), Vector3(-15,0,8), Vector3(15,0,10), Vector3(-10,0,17), Vector3(10,0,19)]:
        var trunk := MeshInstance3D.new()
        var trunk_mesh := CylinderMesh.new()
        trunk_mesh.top_radius = 0.25
        trunk_mesh.bottom_radius = 0.35
        trunk_mesh.height = 2.0
        trunk.mesh = trunk_mesh
        trunk.position = p + Vector3(0,1,0)
        trunk.material_override = material(Color(0.30,0.18,0.10))
        add_child(trunk)
        var crown := MeshInstance3D.new()
        var crown_mesh := SphereMesh.new()
        crown_mesh.radius = 1.35
        crown_mesh.height = 2.4
        crown.mesh = crown_mesh
        crown.position = p + Vector3(0,2.8,0)
        crown.material_override = material(Color(0.13,0.34,0.19))
        add_child(crown)

    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.62, 0.68, 0.82)
    env.ambient_light_energy = 0.8
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -35, 0)
    sun.light_energy = 1.25
    add_child(sun)

    var camera := Camera3D.new()
    camera.projection = Camera3D.PROJECTION_ORTHOGONAL
    camera.size = 25
    camera.position = Vector3(18, 22, 18)
    camera.rotation_degrees = Vector3(-38, 45, 0)
    camera.current = true
    add_child(camera)
    camera.set_script(load("res://scripts/follow_camera.gd"))
    camera.target_path = NodePath("../Player")

func build_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0, 0.9, 5)
    player.set_script(load("res://scripts/player.gd"))
    player.speed = 6.0
    var player_collision := CollisionShape3D.new()
    var player_shape := CapsuleShape3D.new()
    player_shape.radius = 0.48
    player_shape.height = 1.8
    player_collision.shape = player_shape
    player.add_child(player_collision)
    add_child(player)

    var body := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.8
    body.mesh = capsule
    body.material_override = material(Color(0.20, 0.48, 0.82))
    player.add_child(body)

    var head := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.38
    sphere.height = 0.76
    head.mesh = sphere
    head.position = Vector3(0, 1.0, 0)
    head.material_override = material(Color(0.88, 0.69, 0.53))
    player.add_child(head)

func build_enemy() -> void:
    enemy = CharacterBody3D.new()
    enemy.name = "Enemy"
    enemy.position = Vector3(0, 0.8, -7)
    var enemy_collision := CollisionShape3D.new()
    var enemy_shape := SphereShape3D.new()
    enemy_shape.radius = 0.8
    enemy_collision.shape = enemy_shape
    enemy.add_child(enemy_collision)
    add_child(enemy)
    var mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.8
    sphere.height = 1.6
    mesh.mesh = sphere
    mesh.material_override = material(Color(0.65, 0.16, 0.20))
    enemy.add_child(mesh)

func build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(18, 18)
    panel.custom_minimum_size = Vector2(330, 100)
    layer.add_child(panel)
    var vbox := VBoxContainer.new()
    panel.add_child(vbox)
    var title := Label.new()
    title.text = str(player_data.get("name", "Aventureiro")) + " • " + str(player_data.get("race", "Humano"))
    title.add_theme_font_size_override("font_size", 20)
    vbox.add_child(title)
    status_label = Label.new()
    status_label.text = "Vida: 100   Inimigo: 50"
    vbox.add_child(status_label)
    quest_label = Label.new()
    quest_label.text = "Campanha: derrote a criatura diante do templo." if player_data.get("mode", "Campanha") == "Campanha" else "Jogo livre: explore e crie sua própria história."
    vbox.add_child(quest_label)

    var help := Label.new()
    help.text = "WASD / setas: mover  |  Espaço: atacar"
    help.position = Vector2(18, 130)
    layer.add_child(help)

    # Controles táteis básicos para Android
    var controls := HBoxContainer.new()
    controls.anchor_left = 0.5
    controls.anchor_top = 1.0
    controls.anchor_right = 0.5
    controls.anchor_bottom = 1.0
    controls.position = Vector2(-270, -92)
    controls.add_theme_constant_override("separation", 10)
    layer.add_child(controls)
    add_touch_button(controls, "◀", "move_left")
    add_touch_button(controls, "▲", "move_forward")
    add_touch_button(controls, "▼", "move_back")
    add_touch_button(controls, "▶", "move_right")
    var attack_button := Button.new()
    attack_button.text = "ATACAR"
    attack_button.custom_minimum_size = Vector2(110, 64)
    attack_button.button_down.connect(func(): Input.action_press("attack"))
    attack_button.button_up.connect(func(): Input.action_release("attack"))
    controls.add_child(attack_button)

    var back := Button.new()
    back.text = "MENU"
    back.position = Vector2(1120, 18)
    back.pressed.connect(func(): get_tree().reload_current_scene())
    layer.add_child(back)

func add_touch_button(parent: HBoxContainer, label_text: String, action_name: String) -> void:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size = Vector2(58, 64)
    button.button_down.connect(func(): Input.action_press(action_name))
    button.button_up.connect(func(): Input.action_release(action_name))
    parent.add_child(button)

func _process(delta: float) -> void:
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    if Input.is_action_just_pressed("attack") and attack_cooldown <= 0.0:
        attack_cooldown = 0.55
        if is_instance_valid(enemy) and player.global_position.distance_to(enemy.global_position) < 3.0:
            enemy_health -= 25
            if enemy_health <= 0:
                enemy.queue_free()
                quest_label.text = "Missão concluída! A criatura foi derrotada."
        status_label.text = "Vida: " + str(health) + "   Inimigo: " + str(maxi(enemy_health, 0))
