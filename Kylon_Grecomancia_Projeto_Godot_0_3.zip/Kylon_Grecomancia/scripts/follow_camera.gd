extends Camera3D

var target_path: NodePath = NodePath("../Player")
var target: Node3D

func _ready() -> void:
    target = get_node_or_null(target_path)

func _process(_delta: float) -> void:
    if is_instance_valid(target):
        var desired := target.global_position + Vector3(18, 22, 18)
        global_position = global_position.lerp(desired, 0.12)
        look_at(target.global_position, Vector3.UP)
