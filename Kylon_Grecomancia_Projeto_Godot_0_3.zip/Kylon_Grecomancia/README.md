# Kylon: Grecomancia — projeto-fonte Android (protótipo 0.2.1)

RPG mitológico grego 3D estilizado, câmera isométrica e controles táteis. O destino é um aplicativo Android em APK.

## Modos e conteúdo atual
- Campanha e Jogo Livre na tela inicial.
- Criador inicial: nome, anatomia, raça, classe, especialização e cabelo.
- Pequeno cenário 3D, câmera que acompanha o jogador, movimento e inimigo de teste.
- HUD e botões táteis básicos.

## Requisitos para gerar o APK
- Godot Engine 4.x compatível com o projeto (Godot 4.3+; use a mesma versão para os templates).
- Export templates do Godot instalados.
- OpenJDK 17 ou versão recomendada pela versão do Godot.
- Android SDK (Platform Tools, Build Tools e plataforma Android instalada).

## Abrir e testar
1. Extraia o ZIP e abra `project.godot` no Godot.
2. Importe o projeto e execute com F6/F5.
3. Teste movimento, colisões, interface e combate antes de distribuir.

## Exportar APK
1. No Godot, configure JDK e Android SDK em Editor > Editor Settings > Export > Android.
2. Instale os Export Templates correspondentes à versão instalada do Godot.
3. Abra Projeto > Exportar. O preset `Android APK` já está incluído como ponto de partida.
4. Revise o identificador `com.kylon.grecomancia`, SDK alvo e assinatura conforme as exigências atuais da Play Store/dispositivo.
5. Exporte para `build/Kylon_Grecomancia.apk`.

## Estado honesto
Este pacote é **código-fonte**, não é um APK compilado. O ambiente em que este arquivo foi preparado não possui Godot, Android SDK nem templates de exportação e não conseguiu instalar dependências externas. Portanto, não foi possível compilar ou testar o APK aqui. O preset Android é um ponto de partida e pode exigir ajuste conforme a versão do Godot/SDK.

O jogo ainda é um protótipo: faltam arte final/modelos e animações, mapa e regiões, missões completas, diálogos, inventário, progressão, salvamento, áudio, otimização e testes em aparelhos reais.
